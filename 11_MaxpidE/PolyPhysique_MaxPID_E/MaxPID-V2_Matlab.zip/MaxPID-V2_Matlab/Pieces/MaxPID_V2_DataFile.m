    % Simscape(TM) Multibody(TM) version: 7.4

% This is a model data file derived from a Simscape Multibody Import XML file using the smimport function.
% The data in this file sets the block parameter values in an imported Simscape Multibody model.
% For more information on this file, see the smimport function help page in the Simscape Multibody documentation.
% You can modify numerical values, but avoid any other changes to this file.
% Do not add code to this file. Do not edit the physical units shown in comments.

%%%VariableName:smiData


%============= RigidTransform =============%

%Initialize the RigidTransform structure array by filling in null values.
smiData.RigidTransform(104).translation = [0.0 0.0 0.0];
smiData.RigidTransform(104).angle = 0.0;
smiData.RigidTransform(104).axis = [0.0 0.0 0.0];
smiData.RigidTransform(104).ID = '';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(1).translation = [-53.441403017241377 -15.178448275861676 -54.499999999993193];  % mm
smiData.RigidTransform(1).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(1).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(1).ID = 'B[MaxV2_BATI-1:-:MaxV2_BRAS-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(2).translation = [-53.941403017241392 -15.178448275861573 -54.499999999993307];  % mm
smiData.RigidTransform(2).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(2).axis = [-0.57735026918962573 -0.57735026918962584 0.57735026918962573];
smiData.RigidTransform(2).ID = 'F[MaxV2_BATI-1:-:MaxV2_BRAS-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(3).translation = [4.0575969827586267 -15.105183516835551 -136.49996726995653];  % mm
smiData.RigidTransform(3).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(3).axis = [-0.57735026918962573 -0.57735026918962573 0.57735026918962562];
smiData.RigidTransform(3).ID = 'B[MaxV2_BRAS-1:-:MaxV2_ECROU-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(4).translation = [-17.173682347222218 39.305082863483889 -9.2370555648813024e-14];  % mm
smiData.RigidTransform(4).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(4).axis = [-0.57735026918962595 -0.57735026918962584 0.57735026918962551];
smiData.RigidTransform(4).ID = 'F[MaxV2_BRAS-1:-:MaxV2_ECROU-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(5).translation = [14.378830343245363 22.475743589744066 34.500000000000085];  % mm
smiData.RigidTransform(5).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(5).axis = [-1 -3.6039709543131093e-33 3.7708475676557426e-17];
smiData.RigidTransform(5).ID = 'B[MaxV2_VIS-1:-:MaxV2_ECROU-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(6).translation = [-45.92368234722268 39.305082863483435 135.29420828421914];  % mm
smiData.RigidTransform(6).angle = 5.260468782621333e-15;  % rad
smiData.RigidTransform(6).axis = [0.99541852759334348 -0.095613570814503113 -2.5033392559428891e-16];
smiData.RigidTransform(6).ID = 'F[MaxV2_VIS-1:-:MaxV2_ECROU-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(7).translation = [8.5575969827586249 65.821551724148335 15.000000000006814];  % mm
smiData.RigidTransform(7).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(7).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(7).ID = 'B[MaxV2_BATI-1:-:MaxV2_STATOR-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(8).translation = [47.128830343246129 22.475743589744837 -1.9999999999998312];  % mm
smiData.RigidTransform(8).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(8).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962562];
smiData.RigidTransform(8).ID = 'F[MaxV2_BATI-1:-:MaxV2_STATOR-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(9).translation = [14.378830343245664 22.475743589743566 17.499999999999986];  % mm
smiData.RigidTransform(9).angle = 0;  % rad
smiData.RigidTransform(9).axis = [0 0 0];
smiData.RigidTransform(9).ID = 'B[MaxV2_STATOR-1:-:MaxV2_VIS-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(10).translation = [14.378830343246271 22.475743589743274 17.499999999999879];  % mm
smiData.RigidTransform(10).angle = 5.2077034386458019e-15;  % rad
smiData.RigidTransform(10).axis = [-0.55798865560299193 -0.82984857668032763 1.2057033618839971e-15];
smiData.RigidTransform(10).ID = 'F[MaxV2_STATOR-1:-:MaxV2_VIS-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(11).translation = [31.761486089341691 56.020646551724433 -54.499999999979536];  % mm
smiData.RigidTransform(11).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(11).axis = [0 1 0];
smiData.RigidTransform(11).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:MaxV2_ChaiseChapeBras-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(12).translation = [0.76148608934168904 -12.979353448275582 15.000000000020469];  % mm
smiData.RigidTransform(12).angle = 0;  % rad
smiData.RigidTransform(12).axis = [0 0 0];
smiData.RigidTransform(12).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:MaxV2_ChaiseChapeMoteur-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(13).translation = [0.76148608934168904 -12.979353448275582 2.0455859228718509e-11];  % mm
smiData.RigidTransform(13).angle = 0;  % rad
smiData.RigidTransform(13).axis = [0 0 0];
smiData.RigidTransform(13).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:MaxV2_ChaiseBloc-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(14).translation = [-30.238513910658309 56.020646551724418 -54.499999999979536];  % mm
smiData.RigidTransform(14).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(14).axis = [-0 -1 -0];
smiData.RigidTransform(14).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:MaxV2_ChaiseChapeBras-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(15).translation = [29.761486089341691 56.020646551724433 -54.499999999979536];  % mm
smiData.RigidTransform(15).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(15).axis = [0 1 0];
smiData.RigidTransform(15).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Bague_INA_30_34_16-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(16).translation = [-28.238513910658305 56.020646551724418 -54.499999999979536];  % mm
smiData.RigidTransform(16).angle = 1.8850169416765663;  % rad
smiData.RigidTransform(16).axis = [-0.48590330973690732 -0.72649566218487382 0.48590330973690732];
smiData.RigidTransform(16).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Bague_INA_30_34_16-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(17).translation = [-19.238513910658313 11.020646551724411 30.000000000020457];  % mm
smiData.RigidTransform(17).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(17).axis = [0 1 0];
smiData.RigidTransform(17).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:socket head cap screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(18).translation = [20.761486089341691 -4.9793534482755755 -3.9999999999795479];  % mm
smiData.RigidTransform(18).angle = 0;  % rad
smiData.RigidTransform(18).axis = [0 0 0];
smiData.RigidTransform(18).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Goupille_d4-8-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(19).translation = [20.761486089341691 11.020646551724418 30.000000000020457];  % mm
smiData.RigidTransform(19).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(19).axis = [0 1 0];
smiData.RigidTransform(19).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:socket head cap screw_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(20).translation = [-46.238513910658305 11.020646551724418 -74.499999999979522];  % mm
smiData.RigidTransform(20).angle = 0;  % rad
smiData.RigidTransform(20).axis = [0 0 0];
smiData.RigidTransform(20).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:socket head cap screw_iso-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(21).translation = [-46.238513910658305 11.020646551724418 -34.499999999979551];  % mm
smiData.RigidTransform(21).angle = 0;  % rad
smiData.RigidTransform(21).axis = [0 0 0];
smiData.RigidTransform(21).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:socket head cap screw_iso-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(22).translation = [27.761486089341695 -4.9793534482755755 -34.499999999979551];  % mm
smiData.RigidTransform(22).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(22).axis = [0 1 0];
smiData.RigidTransform(22).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Goupille_d4-8-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(23).translation = [27.761486089341695 -4.9793534482755755 -74.499999999979522];  % mm
smiData.RigidTransform(23).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(23).axis = [0 1 0];
smiData.RigidTransform(23).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Goupille_d4-8-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(24).translation = [-19.238513910658305 -4.9793534482755755 -3.9999999999795479];  % mm
smiData.RigidTransform(24).angle = 0;  % rad
smiData.RigidTransform(24).axis = [0 0 0];
smiData.RigidTransform(24).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Goupille_d4-8-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(25).translation = [47.761486089341687 11.020646551724433 -34.499999999979551];  % mm
smiData.RigidTransform(25).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(25).axis = [0 0.83121877946981937 -0.55594544755461739];
smiData.RigidTransform(25).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:socket head cap screw_iso-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(26).translation = [-26.238513910658309 -4.9793534482755888 -74.499999999979522];  % mm
smiData.RigidTransform(26).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(26).axis = [-0 -1 -0];
smiData.RigidTransform(26).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Goupille_d4-8-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(27).translation = [-26.238513910658309 -4.9793534482755755 -34.499999999979551];  % mm
smiData.RigidTransform(27).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(27).axis = [-0 -1 -0];
smiData.RigidTransform(27).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:Goupille_d4-8-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(28).translation = [47.761486089341687 11.020646551724433 -74.499999999979522];  % mm
smiData.RigidTransform(28).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(28).axis = [0 0.83121877946981937 -0.55594544755461739];
smiData.RigidTransform(28).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1:socket head cap screw_iso-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(29).translation = [-25.20388910658307 -71.199094827586094 -1.3655743202889425e-11];  % mm
smiData.RigidTransform(29).angle = 0;  % rad
smiData.RigidTransform(29).axis = [0 0 0];
smiData.RigidTransform(29).ID = 'AssemblyGround[MaxV2_BATI-1:MaxV2_Chaise-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(30).translation = [15.557596982758632 54.821551724148335 15.000000000006814];  % mm
smiData.RigidTransform(30).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(30).axis = [0 0.83121877946981937 -0.55594544755461739];
smiData.RigidTransform(30).ID = 'AssemblyGround[MaxV2_BATI-1:socket head cap screw_iso-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(31).translation = [43.557596982758618 -15.178448275861484 -38.749999999993179];  % mm
smiData.RigidTransform(31).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(31).axis = [0 0.83121877946981937 -0.55594544755461739];
smiData.RigidTransform(31).ID = 'AssemblyGround[MaxV2_BATI-1:plain washer small grade a_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(32).translation = [43.557596982758618 -15.178448275861824 -70.249999999993179];  % mm
smiData.RigidTransform(32).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(32).axis = [0 0.83121877946981937 -0.55594544755461739];
smiData.RigidTransform(32).ID = 'AssemblyGround[MaxV2_BATI-1:plain washer small grade a_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(33).translation = [-15.770241229767011 18.249162018368654 7.1999999999999984];  % mm
smiData.RigidTransform(33).angle = 1.6585870074004081;  % rad
smiData.RigidTransform(33).axis = [0.91584909760330391 0.28391938153216473 0.28391938153216467];
smiData.RigidTransform(33).ID = 'AssemblyGround[MaxV2_BATI-1:PMR411-1:PMR411_Languette-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(34).translation = [-14.45081068239535 19.154205128205149 -10.299999999999997];  % mm
smiData.RigidTransform(34).angle = 0;  % rad
smiData.RigidTransform(34).axis = [0 0 0];
smiData.RigidTransform(34).ID = 'AssemblyGround[MaxV2_BATI-1:PMR411-1:PMR411_Corps-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(35).translation = [-14.450810682395362 19.154205128205149 -1.799999999999996];  % mm
smiData.RigidTransform(35).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(35).axis = [1 0 0];
smiData.RigidTransform(35).ID = 'AssemblyGround[MaxV2_BATI-1:PMR411-1:PMR411_Rivet-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(36).translation = [-14.450810682395353 19.154205128205149 6.6999999999999975];  % mm
smiData.RigidTransform(36).angle = 0.0094137632056999643;  % rad
smiData.RigidTransform(36).axis = [0 0 1];
smiData.RigidTransform(36).ID = 'AssemblyGround[MaxV2_BATI-1:PMR411-1:PMR411_RondelleFriction-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(37).translation = [33.257596982758614 -1.1746588115130081 -35.016586949144276];  % mm
smiData.RigidTransform(37).angle = 2.0810882072813697;  % rad
smiData.RigidTransform(37).axis = [-0.57284555096345358 -0.5862558737298541 0.57284555096345358];
smiData.RigidTransform(37).ID = 'AssemblyGround[MaxV2_BATI-1:PMR411-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(38).translation = [48.057596982758618 -15.178448275861484 -38.749999999993179];  % mm
smiData.RigidTransform(38).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(38).axis = [0 0.55594544755461739 0.83121877946981937];
smiData.RigidTransform(38).ID = 'AssemblyGround[MaxV2_BATI-1:socket head cap screw_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(39).translation = [-60.442403017241375 65.821551724148335 15.000000000006814];  % mm
smiData.RigidTransform(39).angle = 2.0943951023931957;  % rad
smiData.RigidTransform(39).axis = [0.57735026918962551 0.57735026918962573 0.57735026918962595];
smiData.RigidTransform(39).ID = 'AssemblyGround[MaxV2_BATI-1:Max_AxeArticulation-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(40).translation = [11.557596982758625 65.821551724148335 15.000000000006814];  % mm
smiData.RigidTransform(40).angle = 2.0943951023931953;  % rad
smiData.RigidTransform(40).axis = [-0.57735026918962584 -0.57735026918962584 0.57735026918962584];
smiData.RigidTransform(40).ID = 'AssemblyGround[MaxV2_BATI-1:Max_AxeArticulation-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(41).translation = [26.78759698275859 -3.2767372215771822 -37.502595080996791];  % mm
smiData.RigidTransform(41).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(41).axis = [0 0.98264599672514619 -0.1854908221989538];
smiData.RigidTransform(41).ID = 'AssemblyGround[MaxV2_BATI-1:socket countersunk head screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(42).translation = [48.057596982758618 -15.178448275861824 -70.249999999993179];  % mm
smiData.RigidTransform(42).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(42).axis = [0 0.55594544755461739 0.83121877946981937];
smiData.RigidTransform(42).ID = 'AssemblyGround[MaxV2_BATI-1:socket head cap screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(43).translation = [-64.442403017241389 54.821551724148335 15.000000000006814];  % mm
smiData.RigidTransform(43).angle = 0;  % rad
smiData.RigidTransform(43).axis = [0 0 0];
smiData.RigidTransform(43).ID = 'AssemblyGround[MaxV2_BATI-1:socket head cap screw_iso-5]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(44).translation = [22.557596982758614 -15.178448275861653 -54.499999999993165];  % mm
smiData.RigidTransform(44).angle = 1.7856574857530656;  % rad
smiData.RigidTransform(44).axis = [0.41921545984175207 0.80530540570601949 0.41921545984175207];
smiData.RigidTransform(44).ID = 'AssemblyGround[MaxV2_BATI-1:Max_RondellePotar-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(45).translation = [26.78759698275859 -27.080159330146124 -71.497404918989574];  % mm
smiData.RigidTransform(45).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(45).axis = [0 0.98264599672514619 -0.1854908221989538];
smiData.RigidTransform(45).ID = 'AssemblyGround[MaxV2_BATI-1:socket countersunk head screw_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(46).translation = [-15.93141725232368 -13.906605396524995 -0.10172276134306005];  % mm
smiData.RigidTransform(46).angle = 1.6239914318289093;  % rad
smiData.RigidTransform(46).axis = [-0.94817119208229361 -0.22469022064304689 -0.22469022064304689];
smiData.RigidTransform(46).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_EcrouSerragePoids-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(47).translation = [-15.93141725232368 44.093394603474998 -0.10172276134306005];  % mm
smiData.RigidTransform(47).angle = 1.0177622886674382;  % rad
smiData.RigidTransform(47).axis = [0 1 0];
smiData.RigidTransform(47).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_AxeRessort-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(48).translation = [-15.931417252323673 -7.9066053965250047 -0.10172276134306005];  % mm
smiData.RigidTransform(48).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(48).axis = [-1 -0 -0];
smiData.RigidTransform(48).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_Poids-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(49).translation = [-15.931417252323673 34.093394603474991 -0.10172276134306005];  % mm
smiData.RigidTransform(49).angle = 2.8820698019727318;  % rad
smiData.RigidTransform(49).axis = [0.13049467360775335 0.70106031843201844 -0.70106031843201833];
smiData.RigidTransform(49).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_EcrouSerragePoids-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(50).translation = [-15.93141725232368 -61.906605396524995 -0.10172276134306005];  % mm
smiData.RigidTransform(50).angle = 0;  % rad
smiData.RigidTransform(50).axis = [0 0 0];
smiData.RigidTransform(50).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_AxePoids-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(51).translation = [-15.931417252323673 4.0933946034749926 -0.10172276134306005];  % mm
smiData.RigidTransform(51).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(51).axis = [-1 -0 -0];
smiData.RigidTransform(51).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_Poids-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(52).translation = [-15.931417252323673 16.093394603475002 -0.10172276134306005];  % mm
smiData.RigidTransform(52).angle = 1.5707963267948968;  % rad
smiData.RigidTransform(52).axis = [-1 -0 -0];
smiData.RigidTransform(52).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1:Max_Poids-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(53).translation = [12.053855879361755 9.9153863685514523 -251.90660539655229];  % mm
smiData.RigidTransform(53).angle = 1.844997410532798;  % rad
smiData.RigidTransform(53).axis = [-0.75752166716060187 -0.46160639281872085 0.46160639281872085];
smiData.RigidTransform(53).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EnsembleAxePoids-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(54).translation = [29.840595121473356 20.360131269591818 -194.00000000002728];  % mm
smiData.RigidTransform(54).angle = 1.9603168985661301;  % rad
smiData.RigidTransform(54).axis = [-0.52462211562373706 0.52462211562373706 -0.67047988157509131];
smiData.RigidTransform(54).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:socket button head screw_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(55).translation = [-73.130076912903135 15.710131269591812 -184.00000000002731];  % mm
smiData.RigidTransform(55).angle = 1.5707963267948966;  % rad
smiData.RigidTransform(55).axis = [-1 -0 -0];
smiData.RigidTransform(55).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:Max_EquerreRepérage2012-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(56).translation = [4.8405951214733554 -4.2898687304081884 -2.7283730830163222e-11];  % mm
smiData.RigidTransform(56).angle = 0;  % rad
smiData.RigidTransform(56).axis = [0 0 0];
smiData.RigidTransform(56).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:MaxV2_Bras-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(57).translation = [-20.159404878526644 20.360131269591818 -194.00000000002728];  % mm
smiData.RigidTransform(57).angle = 1.9603168985661301;  % rad
smiData.RigidTransform(57).axis = [-0.52462211562373706 0.52462211562373706 -0.67047988157509131];
smiData.RigidTransform(57).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1:socket button head screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(58).translation = [-29.282998138714728 -10.888581257740721 -54.496167119492789];  % mm
smiData.RigidTransform(58).angle = 0.00089347278993698017;  % rad
smiData.RigidTransform(58).axis = [1 -1.2738412740895014e-13 0];
smiData.RigidTransform(58).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_EnsembleBras-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(59).translation = [-73.442403017241361 -15.178448275861554 -54.499999999993307];  % mm
smiData.RigidTransform(59).angle = 3.1409608729317302;  % rad
smiData.RigidTransform(59).axis = [-0.70710674590661826 0.00031589033953866719 -0.70710674590661815];
smiData.RigidTransform(59).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_AxeBras-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(60).translation = [7.0575969827586258 -15.105183516835551 -136.49996726995653];  % mm
smiData.RigidTransform(60).angle = 1.5707965263682901;  % rad
smiData.RigidTransform(60).axis = [0.00044673633552750258 -0.99999980042662651 -0.00044673633552724871];
smiData.RigidTransform(60).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_AxeArticulation-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(61).translation = [11.057596982758632 -15.095355317453185 -147.49996287934209];  % mm
smiData.RigidTransform(61).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(61).axis = [0 0.83121877946981937 -0.5559454475546175];
smiData.RigidTransform(61).ID = 'AssemblyGround[MaxV2_BRAS-1:socket head cap screw_iso-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(62).translation = [-55.942403017241389 -15.105183516836034 -136.4999672699565];  % mm
smiData.RigidTransform(62).angle = 3.1409608729317364;  % rad
smiData.RigidTransform(62).axis = [-0.70710674590661804 0.00031589033953568102 -0.70710674590661837];
smiData.RigidTransform(62).ID = 'AssemblyGround[MaxV2_BRAS-1:Max_AxeArticulation-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(63).translation = [-59.942403017241375 -15.095355317453187 -147.49996287934218];  % mm
smiData.RigidTransform(63).angle = 0;  % rad
smiData.RigidTransform(63).axis = [0 0 0];
smiData.RigidTransform(63).ID = 'AssemblyGround[MaxV2_BRAS-1:socket head cap screw_iso-6]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(64).translation = [-9.4424030172413964 5.8215433420559393 -54.481237073900814];  % mm
smiData.RigidTransform(64).angle = 1.8379889424485198;  % rad
smiData.RigidTransform(64).axis = [-0.45702978851995368 0.45771137173242082 -0.76264282111105719];
smiData.RigidTransform(64).ID = 'AssemblyGround[MaxV2_BRAS-1:socket set screw flat point_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(65).translation = [-39.442403017241396 5.8215433420559375 -54.481237073900814];  % mm
smiData.RigidTransform(65).angle = 2.1538627903614289;  % rad
smiData.RigidTransform(65).axis = [-0.59588813618509606 0.59636891091487076 -0.53783031826781891];
smiData.RigidTransform(65).ID = 'AssemblyGround[MaxV2_BRAS-1:socket set screw flat point_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(66).translation = [29.581626138756498 37.67853938525424 -37.000000000000007];  % mm
smiData.RigidTransform(66).angle = 1.570796326794897;  % rad
smiData.RigidTransform(66).axis = [-1.1102230246251564e-16 -1 8.3266726846886716e-17];
smiData.RigidTransform(66).ID = 'AssemblyGround[MaxV2_STATOR-1:socket head cap screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(67).translation = [-0.82396545226508944 37.678539385254368 -37.000000000000007];  % mm
smiData.RigidTransform(67).angle = 1.570796326794897;  % rad
smiData.RigidTransform(67).axis = [-1.1102230246251564e-16 -1 8.3266726846886716e-17];
smiData.RigidTransform(67).ID = 'AssemblyGround[MaxV2_STATOR-1:socket head cap screw_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(68).translation = [14.378830343245664 22.475743589743566 -30];  % mm
smiData.RigidTransform(68).angle = 0;  % rad
smiData.RigidTransform(68).axis = [0 0 0];
smiData.RigidTransform(68).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_SupportVisBilles-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(69).translation = [-9.6211696567543381 22.47574358974358 -2.0000000000000018];  % mm
smiData.RigidTransform(69).angle = 2.3630396760125953;  % rad
smiData.RigidTransform(69).axis = [-0.64487527590269911 0.41020940635099473 -0.644875275902699];
smiData.RigidTransform(69).ID = 'AssemblyGround[MaxV2_STATOR-1:Bague_INA_12_14_7-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(70).translation = [14.378830343245664 22.475743589743573 35.500000000000028];  % mm
smiData.RigidTransform(70).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(70).axis = [0.34590986353999686 0.93826774766360843 0];
smiData.RigidTransform(70).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_EcrouSupportVisBilles-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(71).translation = [-0.82396545226520046 7.2729477942329037 -36.99999999999995];  % mm
smiData.RigidTransform(71).angle = 1.5740165414112079;  % rad
smiData.RigidTransform(71).axis = [-0.056655737485803707 -0.99678495916615795 -0.056655737485803707];
smiData.RigidTransform(71).ID = 'AssemblyGround[MaxV2_STATOR-1:socket head cap screw_iso-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(72).translation = [-51.517887252092166 7.6799381151886337 10.539197232560596];  % mm
smiData.RigidTransform(72).angle = 0;  % rad
smiData.RigidTransform(72).axis = [0 0 0];
smiData.RigidTransform(72).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:RE35_2822-1:RE35_273752-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(73).translation = [19.482112747907841 7.6799381151886266 10.539197232560582];  % mm
smiData.RigidTransform(73).angle = 0.78539816339922497;  % rad
smiData.RigidTransform(73).axis = [-1 -3.1401849173619716e-16 -9.3224239734183526e-16];
smiData.RigidTransform(73).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:RE35_2822-1:Tachy_2822-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(74).translation = [-7.9580772764641932 28.953048196905979 -10.553851946106946];  % mm
smiData.RigidTransform(74).angle = 0;  % rad
smiData.RigidTransform(74).axis = [0 0 0];
smiData.RigidTransform(74).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:RE35_2822-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(75).translation = [-67.275964528556386 46.132986312094609 -0.01465471354634984];  % mm
smiData.RigidTransform(75).angle = 0;  % rad
smiData.RigidTransform(75).axis = [0 0 0];
smiData.RigidTransform(75).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:slotted cheese head screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(76).translation = [-59.47596452855641 36.632986312094609 -0.014654713546363718];  % mm
smiData.RigidTransform(76).angle = 1.8234765819369732;  % rad
smiData.RigidTransform(76).axis = [-0.44721359549995648 -0.77459666924148507 0.44721359549995654];
smiData.RigidTransform(76).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:Max_BrideMoteur-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(77).translation = [-67.275964528556358 31.88298631209458 -8.2418960494984876];  % mm
smiData.RigidTransform(77).angle = 1.0275895117910028;  % rad
smiData.RigidTransform(77).axis = [1 0 0];
smiData.RigidTransform(77).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:slotted cheese head screw_iso-3]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(78).translation = [-67.275964528556358 31.882986312094573 8.2125866224058015];  % mm
smiData.RigidTransform(78).angle = 1.2957842657065441;  % rad
smiData.RigidTransform(78).axis = [1 0 0];
smiData.RigidTransform(78).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1:slotted cheese head screw_iso-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(79).translation = [-21.009710148666759 31.942902760002333 -92.475964528556361];  % mm
smiData.RigidTransform(79).angle = 2.2515894312114528;  % rad
smiData.RigidTransform(79).axis = [0.62151487829198904 0.47690513954390157 -0.62151487829198893];
smiData.RigidTransform(79).ID = 'AssemblyGround[MaxV2_STATOR-1:Max_MoteurEquipé-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(80).translation = [38.378830343245667 22.475743589743594 -2.0000000000000018];  % mm
smiData.RigidTransform(80).angle = 2.1236160109962592;  % rad
smiData.RigidTransform(80).axis = [-0.58677130229575536 -0.55803125145845223 0.58677130229575547];
smiData.RigidTransform(80).ID = 'AssemblyGround[MaxV2_STATOR-1:Bague_INA_12_14_7-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(81).translation = [29.581626138756491 7.2729477942328895 -37.000000000000007];  % mm
smiData.RigidTransform(81).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(81).axis = [0.70710678118654746 -7.8504622934188758e-17 0.70710678118654757];
smiData.RigidTransform(81).ID = 'AssemblyGround[MaxV2_STATOR-1:socket head cap screw_iso-4]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(82).translation = [14.37883034324644 22.4757435897424 212.32355339059339];  % mm
smiData.RigidTransform(82).angle = 2.0908372819075729;  % rad
smiData.RigidTransform(82).axis = [-0.5761594393406877 0.57972459057491155 0.57615943934068758];
smiData.RigidTransform(82).ID = 'AssemblyGround[MaxV2_VIS-1:socket countersunk head screw_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(83).translation = [14.37883034324644 22.475743589742393 201.50000000000011];  % mm
smiData.RigidTransform(83).angle = 2.457787977897921;  % rad
smiData.RigidTransform(83).axis = [-1.1583830548910573e-16 6.2541619012023126e-17 -1];
smiData.RigidTransform(83).ID = 'AssemblyGround[MaxV2_VIS-1:Max_RondelleVisBilles-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(84).translation = [-49.39470811829279 15.389794871794857 0];  % mm
smiData.RigidTransform(84).angle = 0;  % rad
smiData.RigidTransform(84).axis = [0 0 0];
smiData.RigidTransform(84).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Oldham_235_19_20_22-1:Oldham_MoyeuD6-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(85).translation = [-49.39470811829279 15.389794871794857 0];  % mm
smiData.RigidTransform(85).angle = 0;  % rad
smiData.RigidTransform(85).axis = [0 0 0];
smiData.RigidTransform(85).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Oldham_235_19_20_22-1:Oldham_Disque-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(86).translation = [-49.39470811829279 15.389794871794857 0];  % mm
smiData.RigidTransform(86).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(86).axis = [0.70710678118654746 0.70710678118654757 0];
smiData.RigidTransform(86).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Oldham_235_19_20_22-1:Oldham_MoyeuD5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(87).translation = [-90.326435235180938 5.7926486221493292 108.59163796009905];  % mm
smiData.RigidTransform(87).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(87).axis = [-0.19719034051814069 0.98036522256062308 1.5571305710665323e-16];
smiData.RigidTransform(87).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Oldham_235_19_20_22-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(88).translation = [-50.723323502908158 39.083435897435884 -100.90836203990089];  % mm
smiData.RigidTransform(88).angle = 0;  % rad
smiData.RigidTransform(88).axis = [0 0 0];
smiData.RigidTransform(88).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Max_VisBilles12x4-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(89).translation = [-50.723323502908173 39.083435897435891 88.991637960099069];  % mm
smiData.RigidTransform(89).angle = 0;  % rad
smiData.RigidTransform(89).axis = [0 0 0];
smiData.RigidTransform(89).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:torque nut 08_iso-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(90).translation = [-50.723323502908173 39.083435897435891 66.091637960099064];  % mm
smiData.RigidTransform(90).angle = 1.1411537431436602;  % rad
smiData.RigidTransform(90).axis = [0 0 1];
smiData.RigidTransform(90).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Max_BagueVisBilles-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(91).translation = [0 0 0];  % mm
smiData.RigidTransform(91).angle = 0;  % rad
smiData.RigidTransform(91).axis = [0 0 0];
smiData.RigidTransform(91).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1:3200_a-2rs1-2_1_01-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(92).translation = [0 0 0];  % mm
smiData.RigidTransform(92).angle = 0;  % rad
smiData.RigidTransform(92).axis = [0 0 0];
smiData.RigidTransform(92).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1:3200_a-2rs1-2_1_03-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(93).translation = [0 0 0];  % mm
smiData.RigidTransform(93).angle = 0;  % rad
smiData.RigidTransform(93).axis = [0 0 0];
smiData.RigidTransform(93).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1:3200_a-2rs1-2_1_05-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(94).translation = [0 0 0];  % mm
smiData.RigidTransform(94).angle = 0;  % rad
smiData.RigidTransform(94).axis = [0 0 0];
smiData.RigidTransform(94).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1:3200_a-2rs1-2_1_06-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(95).translation = [0 0 0];  % mm
smiData.RigidTransform(95).angle = 0;  % rad
smiData.RigidTransform(95).axis = [0 0 0];
smiData.RigidTransform(95).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1:3200_a-2rs1-2_1_02-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(96).translation = [0 0 0];  % mm
smiData.RigidTransform(96).angle = 0;  % rad
smiData.RigidTransform(96).axis = [0 0 0];
smiData.RigidTransform(96).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1:3200_a-2rs1-2_1_04-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(97).translation = [-50.723323502908165 39.083435897435891 76.091637960099078];  % mm
smiData.RigidTransform(97).angle = 1.7468417512545658;  % rad
smiData.RigidTransform(97).axis = [0.38605148718044285 -0.83781173212812954 0.38605148718044296];
smiData.RigidTransform(97).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:3200_a-2rs1-2_1-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(98).translation = [-50.723323502908158 39.083435897435891 83.091637960099078];  % mm
smiData.RigidTransform(98).angle = 1.1807864303470414;  % rad
smiData.RigidTransform(98).axis = [6.0018200126515999e-17 0 1];
smiData.RigidTransform(98).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1:Max_RondelleD6.5-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(99).translation = [-21.688347430096762 75.386320946221559 100.59163796009913];  % mm
smiData.RigidTransform(99).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(99).axis = [-0.72737906407114705 -0.68623589031103738 -3.8158337222796476e-17];
smiData.RigidTransform(99).ID = 'AssemblyGround[MaxV2_VIS-1:Max_VisBillesRotor-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(100).translation = [-45.923682347222659 39.305082863484046 -18];  % mm
smiData.RigidTransform(100).angle = 0;  % rad
smiData.RigidTransform(100).axis = [0 0 0];
smiData.RigidTransform(100).ID = 'AssemblyGround[MaxV2_ECROU-1:Max_SupportEcrou-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(101).translation = [-45.923682347222659 39.305082863484046 16.999999999999986];  % mm
smiData.RigidTransform(101).angle = 3.1415926535897931;  % rad
smiData.RigidTransform(101).axis = [-0.17021094102836959 0.98540764942953285 0];
smiData.RigidTransform(101).ID = 'AssemblyGround[MaxV2_ECROU-1:Max_EcrouBilles-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(102).translation = [-24.923682347222663 39.305082863484039 0];  % mm
smiData.RigidTransform(102).angle = 1.7269267342981616;  % rad
smiData.RigidTransform(102).axis = [0.36683977822774333 -0.85490183893803862 -0.36683977822774361];
smiData.RigidTransform(102).ID = 'AssemblyGround[MaxV2_ECROU-1:Bague_INA_12_14_7-1]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(103).translation = [-66.923682347222652 39.305082863484046 0];  % mm
smiData.RigidTransform(103).angle = 1.9619977657210577;  % rad
smiData.RigidTransform(103).axis = [0.52539886925605872 0.66926232253796403 0.52539886925605861];
smiData.RigidTransform(103).ID = 'AssemblyGround[MaxV2_ECROU-1:Bague_INA_12_14_7-2]';

%Translation Method - Cartesian
%Rotation Method - Arbitrary Axis
smiData.RigidTransform(104).translation = [-1.0108471100543777 9.8778188125668986 195.15453584414843];  % mm
smiData.RigidTransform(104).angle = 0;  % rad
smiData.RigidTransform(104).axis = [0 0 0];
smiData.RigidTransform(104).ID = 'RootGround[MaxV2_BATI-1]';


%============= Solid =============%
%Center of Mass (CoM) %Moments of Inertia (MoI) %Product of Inertia (PoI)

%Initialize the Solid structure array by filling in null values.
smiData.Solid(51).mass = 0.0;
smiData.Solid(51).CoM = [0.0 0.0 0.0];
smiData.Solid(51).MoI = [0.0 0.0 0.0];
smiData.Solid(51).PoI = [0.0 0.0 0.0];
smiData.Solid(51).color = [0.0 0.0 0.0];
smiData.Solid(51).opacity = 0.0;
smiData.Solid(51).ID = '';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(1).mass = 0.19464386550496288;  % kg
smiData.Solid(1).CoM = [0 -26.450811631547708 7.9521238116794475];  % mm
smiData.Solid(1).MoI = [150.06101827548164 66.559130707070224 208.3642055770691];  % kg*mm^2
smiData.Solid(1).PoI = [0.0018318169573085334 0 -0.11053648879204822];  % kg*mm^2
smiData.Solid(1).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(1).opacity = 1;
smiData.Solid(1).ID = 'MaxV2_ChaiseChapeBras*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(2).mass = 0.62778563754424477;  % kg
smiData.Solid(2).CoM = [0 62.383323635805887 -0.044443197417417271];  % mm
smiData.Solid(2).MoI = [985.44787324640311 307.32766472945156 1199.1052446516521];  % kg*mm^2
smiData.Solid(2).PoI = [-1.2110256064739187 0 0];  % kg*mm^2
smiData.Solid(2).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(2).opacity = 1;
smiData.Solid(2).ID = 'MaxV2_ChaiseChapeMoteur*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(3).mass = 0.47660419311585894;  % kg
smiData.Solid(3).CoM = [0 16.973224570945021 -42.285417597797554];  % mm
smiData.Solid(3).MoI = [328.73668076729439 434.29336245983961 197.71266476004152];  % kg*mm^2
smiData.Solid(3).PoI = [0.030411427861285104 0 0];  % kg*mm^2
smiData.Solid(3).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(3).opacity = 1;
smiData.Solid(3).ID = 'MaxV2_ChaiseBloc*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(4).mass = 0.0041174934168214288;  % kg
smiData.Solid(4).CoM = [-2.4510985228558385e-05 -0.059918237762436447 6.467240019373615];  % mm
smiData.Solid(4).MoI = [0.68159887556634069 0.68607981556092401 1.1616122954577821];  % kg*mm^2
smiData.Solid(4).PoI = [-0.00062706173162863565 -5.2770836911242416e-07 1.9643567465141382e-06];  % kg*mm^2
smiData.Solid(4).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(4).opacity = 1;
smiData.Solid(4).ID = 'Bague_INA_30_34_16*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(5).mass = 0.00082983531815194632;  % kg
smiData.Solid(5).CoM = [14.919160990324791 0 0];  % mm
smiData.Solid(5).MoI = [0.0042996070185067634 0.097717379966608023 0.097717379966608023];  % kg*mm^2
smiData.Solid(5).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(5).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(5).opacity = 1;
smiData.Solid(5).ID = 'socket head cap screw_iso*:*ISO 4762 M5 x 30 --- 22N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(6).mass = 0.00076167913886284551;  % kg
smiData.Solid(6).CoM = [0 0 3.9999999999999982];  % mm
smiData.Solid(6).MoI = [0.0045982804447200817 0.0045982804447200817 0.001491859884382636];  % kg*mm^2
smiData.Solid(6).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(6).color = [0.6470588235294118 0.61960784313725492 0.58823529411764708];
smiData.Solid(6).opacity = 1;
smiData.Solid(6).ID = 'Goupille_d4-8*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(7).mass = 0.00055494596096283399;  % kg
smiData.Solid(7).CoM = [8.4765492487310219 0 0];  % mm
smiData.Solid(7).MoI = [0.0034405777772907732 0.023257536146613224 0.023257536146613224];  % kg*mm^2
smiData.Solid(7).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(7).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(7).opacity = 1;
smiData.Solid(7).ID = 'socket head cap screw_iso*:*ISO 4762 M5 x 16 --- 16N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(8).mass = 0.00026010820887896382;  % kg
smiData.Solid(8).CoM = [5.404280117733494 0 0];  % mm
smiData.Solid(8).MoI = [0.0011663415058278729 0.0048306522042406647 0.0048306522042406647];  % kg*mm^2
smiData.Solid(8).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(8).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(8).opacity = 1;
smiData.Solid(8).ID = 'socket head cap screw_iso*:*ISO 4762 M4 x 10 --- 10N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(9).mass = 1.78717352081089e-05;  % kg
smiData.Solid(9).CoM = [-0.24999999999976436 0 0];  % mm
smiData.Solid(9).MoI = [0.00018427992966461472 9.2512292648991559e-05 9.2512292648991586e-05];  % kg*mm^2
smiData.Solid(9).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(9).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(9).opacity = 1;
smiData.Solid(9).ID = 'plain washer small grade a_iso*:*Washer ISO 7092 - 4';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(10).mass = 0.00017413844347721147;  % kg
smiData.Solid(10).CoM = [1.6000000000000005 2.2502867388064787 -5.0971976502822969];  % mm
smiData.Solid(10).MoI = [0.010659045631900376 0.010420645928802676 0.0023827556955419577];  % kg*mm^2
smiData.Solid(10).PoI = [0.0030014906929175726 0 0];  % kg*mm^2
smiData.Solid(10).color = [0.75294117647058822 0.75294117647058822 0];
smiData.Solid(10).opacity = 1;
smiData.Solid(10).ID = 'PMR411_Languette*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(11).mass = 0.013616204939908233;  % kg
smiData.Solid(11).CoM = [-2.9594983019062648 0.010971183722352448 8.5377137198029178];  % mm
smiData.Solid(11).MoI = [1.31791435566214 1.2494096481838806 1.8733892878156386];  % kg*mm^2
smiData.Solid(11).PoI = [-0.00062925611804002645 -0.047206564420234298 0.00095587333025698874];  % kg*mm^2
smiData.Solid(11).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(11).opacity = 1;
smiData.Solid(11).ID = 'PMR411_Corps*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(12).mass = 4.7878359728827284e-05;  % kg
smiData.Solid(12).CoM = [0 7.0006876096819033 0];  % mm
smiData.Solid(12).MoI = [0.00064791689106252282 0.00014223976318773551 0.00064791689106252282];  % kg*mm^2
smiData.Solid(12).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(12).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(12).opacity = 1;
smiData.Solid(12).ID = 'PMR411_Rivet*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(13).mass = 9.6996673179584807e-05;  % kg
smiData.Solid(13).CoM = [0 0 0.25];  % mm
smiData.Solid(13).MoI = [0.0016085281635614473 0.0016085281635614475 0.0032130147990737457];  % kg*mm^2
smiData.Solid(13).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(13).color = [0.50196078431372548 0.50196078431372548 0.50196078431372548];
smiData.Solid(13).opacity = 1;
smiData.Solid(13).ID = 'PMR411_RondelleFriction*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(14).mass = 0.00038577191502255098;  % kg
smiData.Solid(14).CoM = [9.8098704268660519 0 0];  % mm
smiData.Solid(14).MoI = [0.0014176689181150399 0.021503504392095436 0.021503504392095436];  % kg*mm^2
smiData.Solid(14).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(14).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(14).opacity = 1;
smiData.Solid(14).ID = 'socket head cap screw_iso*:*ISO 4762 M4 x 20 --- 20N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(15).mass = 0.0033889276252130388;  % kg
smiData.Solid(15).CoM = [0.1548697348345848 0 4.4343942524961886];  % mm
smiData.Solid(15).MoI = [0.19045911985451888 0.18460457211358017 0.25131614956928988];  % kg*mm^2
smiData.Solid(15).PoI = [0 0.0015400942951692958 0];  % kg*mm^2
smiData.Solid(15).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(15).opacity = 1;
smiData.Solid(15).ID = 'Max_AxeArticulation*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(16).mass = 0.00013853584587304033;  % kg
smiData.Solid(16).CoM = [3.0850244317484159 0 0];  % mm
smiData.Solid(16).MoI = [0.00058132177718469311 0.0011010262604109048 0.0011010262604109048];  % kg*mm^2
smiData.Solid(16).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(16).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(16).opacity = 1;
smiData.Solid(16).ID = 'socket countersunk head screw_iso*:*ISO 10642 - M4 x 8 --- 8N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(17).mass = 0.045298152611588885;  % kg
smiData.Solid(17).CoM = [0 0 1.9827866816114277];  % mm
smiData.Solid(17).MoI = [8.3026599982065594 9.0200255120273098 17.204609418345111];  % kg*mm^2
smiData.Solid(17).PoI = [0 0 -0.06220424809159672];  % kg*mm^2
smiData.Solid(17).color = [0.6470588235294118 0.61960784313725492 0.58823529411764708];
smiData.Solid(17).opacity = 1;
smiData.Solid(17).ID = 'Max_RondellePotar*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(18).mass = 0.0037318894430127913;  % kg
smiData.Solid(18).CoM = [0 0 3.6283541124422714];  % mm
smiData.Solid(18).MoI = [0.21563258094489179 0.21563300378221506 0.39041135423597095];  % kg*mm^2
smiData.Solid(18).PoI = [0 0 -1.8828841052920026e-08];  % kg*mm^2
smiData.Solid(18).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(18).opacity = 1;
smiData.Solid(18).ID = 'Max_EcrouSerragePoids*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(19).mass = 0.0040420647378943634;  % kg
smiData.Solid(19).CoM = [0 9.1017144282054776 0];  % mm
smiData.Solid(19).MoI = [0.24068933866749753 0.25214157531470377 0.24068933866749759];  % kg*mm^2
smiData.Solid(19).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(19).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(19).opacity = 1;
smiData.Solid(19).ID = 'Max_AxeRessort*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(20).mass = 0.66126958228690746;  % kg
smiData.Solid(20).CoM = [2.1710243587764664 -1.5108645340624077e-07 6.0000000000000009];  % mm
smiData.Solid(20).MoI = [465.52165607090291 410.98315578051006 860.67205847785283];  % kg*mm^2
smiData.Solid(20).PoI = [0 0 -6.1543838386219093e-06];  % kg*mm^2
smiData.Solid(20).color = [0.6470588235294118 0.61960784313725492 0.58823529411764708];
smiData.Solid(20).opacity = 1;
smiData.Solid(20).ID = 'Max_Poids*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(21).mass = 0.0093311313668168853;  % kg
smiData.Solid(21).CoM = [-0.003093621985861598 51.371858737304741 0.0013619015973647894];  % mm
smiData.Solid(21).MoI = [9.2015844396772408 0.15391423637492163 9.2018719152374384];  % kg*mm^2
smiData.Solid(21).PoI = [-0.0003305934548016466 -0.0016216966539074542 0.00023477718743472581];  % kg*mm^2
smiData.Solid(21).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(21).opacity = 1;
smiData.Solid(21).ID = 'Max_AxePoids*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(22).mass = 9.7175233462313748e-05;  % kg
smiData.Solid(22).CoM = [5.0811372487513333 0 0];  % mm
smiData.Solid(22).MoI = [0.00017927368325104816 0.0012826682860304669 0.0012826682860304669];  % kg*mm^2
smiData.Solid(22).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(22).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(22).opacity = 1;
smiData.Solid(22).ID = 'socket button head screw_iso*:*ISO 7380 - M3 x 10 --- 10N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(23).mass = 0.0061935401271485616;  % kg
smiData.Solid(23).CoM = [57.49562749546476 10.018874060505706 2.4916872072251839];  % mm
smiData.Solid(23).MoI = [0.26681632858930993 5.5245162425037897 5.6699834964279825];  % kg*mm^2
smiData.Solid(23).PoI = [-0.0020410776687620653 0.25458252702745582 0.0048509252226418336];  % kg*mm^2
smiData.Solid(23).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(23).opacity = 1;
smiData.Solid(23).ID = 'Max_EquerreRepérage2012*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(24).mass = 0.41609795015273121;  % kg
smiData.Solid(24).CoM = [2.9477302586434779e-05 -0.032409500008416477 -100.61094620532877];  % mm
smiData.Solid(24).MoI = [2606.4603700389762 2731.0640380943446 242.98287998764707];  % kg*mm^2
smiData.Solid(24).PoI = [0.54766043736234249 0.00015124233995370928 6.1109110539513741e-05];  % kg*mm^2
smiData.Solid(24).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(24).opacity = 1;
smiData.Solid(24).ID = 'MaxV2_Bras*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(25).mass = 0.065363933068377483;  % kg
smiData.Solid(25).CoM = [0 0.2350797901386607 47.173355646672888];  % mm
smiData.Solid(25).MoI = [52.314209957529478 52.517576748074617 7.2482446256584492];  % kg*mm^2
smiData.Solid(25).PoI = [-0.0050191320973620107 0 0.016584495532564213];  % kg*mm^2
smiData.Solid(25).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(25).opacity = 1;
smiData.Solid(25).ID = 'Max_AxeBras*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(26).mass = 0.00018896730197818029;  % kg
smiData.Solid(26).CoM = [4.1950532524054056 0 0];  % mm
smiData.Solid(26).MoI = [0.0009103072072415983 0.0013521296158979343 0.0013521296158979343];  % kg*mm^2
smiData.Solid(26).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(26).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(26).opacity = 1;
smiData.Solid(26).ID = 'socket set screw flat point_iso*:*ISO 4026 - M6 x 8-C';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(27).mass = 0.00023497546765024528;  % kg
smiData.Solid(27).CoM = [4.599455015817064 0 0];  % mm
smiData.Solid(27).MoI = [0.0011160760233704361 0.0032215815638381839 0.0032215815638381839];  % kg*mm^2
smiData.Solid(27).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(27).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(27).opacity = 1;
smiData.Solid(27).ID = 'socket head cap screw_iso*:*ISO 4762 M4 x 8 --- 8N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(28).mass = 0.18260059335272533;  % kg
smiData.Solid(28).CoM = [-5.8285893581584343e-06 1.3991563548600099e-06 26.465389353985273];  % mm
smiData.Solid(28).MoI = [84.522947034911567 78.670674967496055 70.273677692543316];  % kg*mm^2
smiData.Solid(28).PoI = [-6.7314830779600697e-06 1.9616590714180268e-05 0.00011782485088721173];  % kg*mm^2
smiData.Solid(28).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(28).opacity = 1;
smiData.Solid(28).ID = 'Max_SupportVisBilles*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(29).mass = 0.00042578858853302252;  % kg
smiData.Solid(29).CoM = [6.528980441927511e-11 -0.065483608943436175 2.5155700603474678];  % mm
smiData.Solid(29).MoI = [0.013490028373187751 0.013720075414530368 0.023201582623683031];  % kg*mm^2
smiData.Solid(29).PoI = [-2.873570120152846e-05 0 0];  % kg*mm^2
smiData.Solid(29).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(29).opacity = 1;
smiData.Solid(29).ID = 'Bague_INA_12_14_7*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(30).mass = 0.030013558845243621;  % kg
smiData.Solid(30).CoM = [0 0 6.7522874200727774];  % mm
smiData.Solid(30).MoI = [6.9653843197682317 6.9653843197682326 12.692903515986901];  % kg*mm^2
smiData.Solid(30).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(30).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(30).opacity = 1;
smiData.Solid(30).ID = 'Max_EcrouSupportVisBilles*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(31).mass = 0.068740533358668227;  % kg
smiData.Solid(31).CoM = [35.211313526703229 -0.0039079268278424117 -0.00043213320566400933];  % mm
smiData.Solid(31).MoI = [10.305397270518217 35.12855333486489 35.123370470085277];  % kg*mm^2
smiData.Solid(31).PoI = [-0.0031691107485773639 0.0037181348405088371 0.0045352498039128303];  % kg*mm^2
smiData.Solid(31).color = [0.792156862745098 0.81960784313725488 0.93333333333333335];
smiData.Solid(31).opacity = 1;
smiData.Solid(31).ID = 'RE35_273752*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(32).mass = 0.0069201093117687504;  % kg
smiData.Solid(32).CoM = [8.6240465458078504 8.9105838706680137e-05 0.0015843470330895255];  % mm
smiData.Solid(32).MoI = [0.46496255353870991 0.42319649238890927 0.4146720818426588];  % kg*mm^2
smiData.Solid(32).PoI = [0.0035128873254837672 6.6219406394108657e-05 5.7801434252469756e-05];  % kg*mm^2
smiData.Solid(32).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(32).opacity = 1;
smiData.Solid(32).ID = 'Tachy_2822*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(33).mass = 7.39600784531146e-05;  % kg
smiData.Solid(33).CoM = [4.8371025360561273 1.7938080265701464e-10 -2.4000022657665132e-09];  % mm
smiData.Solid(33).MoI = [9.8559701793044945e-05 0.0010259195694862042 0.0010285111099257612];  % kg*mm^2
smiData.Solid(33).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(33).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(33).opacity = 1;
smiData.Solid(33).ID = 'slotted cheese head screw_iso*:*ISO 1207 - M2.5 x 10 --- 10N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(34).mass = 0.018215032745329963;  % kg
smiData.Solid(34).CoM = [0 0 2.1685819201365981];  % mm
smiData.Solid(34).MoI = [2.6468890043509687 2.6468890043509687 5.2099766315024398];  % kg*mm^2
smiData.Solid(34).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(34).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(34).opacity = 1;
smiData.Solid(34).ID = 'Max_BrideMoteur*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(35).mass = 0.00069095342196798671;  % kg
smiData.Solid(35).CoM = [8.3365758259344283 0 0];  % mm
smiData.Solid(35).MoI = [0.0054457554880504525 0.0293260914200053 0.0293260914200053];  % kg*mm^2
smiData.Solid(35).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(35).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(35).opacity = 1;
smiData.Solid(35).ID = 'socket countersunk head screw_iso*:*ISO 10642 - M6 x 20 --- 20N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(36).mass = 0.032402170979562307;  % kg
smiData.Solid(36).CoM = [-3.3196202177009639e-09 7.0603642629646171e-09 4.9617072180728181];  % mm
smiData.Solid(36).MoI = [3.5624766500987657 3.5624766529197354 6.5985381617202279];  % kg*mm^2
smiData.Solid(36).PoI = [7.1964851558343933e-10 0 -8.1179945999798975e-10];  % kg*mm^2
smiData.Solid(36).color = [0.8666666666666667 0.90980392156862744 1];
smiData.Solid(36).opacity = 1;
smiData.Solid(36).ID = 'Max_RondelleVisBilles*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(37).mass = 0.0020596268768442718;  % kg
smiData.Solid(37).CoM = [0.33509538262327504 0.28710976600952537 -6.5516384905336942];  % mm
smiData.Solid(37).MoI = [0.058549453237501797 0.068882610302099689 0.09559522384145458];  % kg*mm^2
smiData.Solid(37).PoI = [0.00078322586616734479 -0.00057328056373455265 0.0017367484683407158];  % kg*mm^2
smiData.Solid(37).color = [0.75294117647058822 0.75294117647058822 0];
smiData.Solid(37).opacity = 1;
smiData.Solid(37).ID = 'Oldham_MoyeuD6*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(38).mass = 0.0012012286416485619;  % kg
smiData.Solid(38).CoM = [0 0 0];  % mm
smiData.Solid(38).MoI = [0.034196266422932144 0.034196266422932151 0.061789375308639427];  % kg*mm^2
smiData.Solid(38).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(38).color = [0.29411764705882354 0.29411764705882354 0.29411764705882354];
smiData.Solid(38).opacity = 1;
smiData.Solid(38).ID = 'Oldham_Disque*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(39).mass = 0.002119042921953483;  % kg
smiData.Solid(39).CoM = [0.32569961334019787 0.27905946810461291 -6.5796094241339471];  % mm
smiData.Solid(39).MoI = [0.059069841935686936 0.069404723238507049 0.096044303061110614];  % kg*mm^2
smiData.Solid(39).PoI = [0.00076668556251647299 -0.00059258531338422576 0.0017311923836166698];  % kg*mm^2
smiData.Solid(39).color = [0.75294117647058822 0.75294117647058822 0];
smiData.Solid(39).opacity = 1;
smiData.Solid(39).ID = 'Oldham_MoyeuD5*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(40).mass = 0.016148169177425564;  % kg
smiData.Solid(40).CoM = [-0.00027319226949303114 0.0035412428032355514 91.998377284044651];  % mm
smiData.Solid(40).MoI = [43.652436867013421 43.652477634160881 0.23836819365143488];  % kg*mm^2
smiData.Solid(40).PoI = [0.0030737071798897005 0.0025148792999098685 -0.00026095878155901769];  % kg*mm^2
smiData.Solid(40).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(40).opacity = 1;
smiData.Solid(40).ID = 'Max_VisBilles12x4*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(41).mass = 0.00034496982504164816;  % kg
smiData.Solid(41).CoM = [0 1.5330290520107104e-06 -0.18829281159573799];  % mm
smiData.Solid(41).MoI = [0.0037617118215706536 0.003761696496025532 0.0057309773901883954];  % kg*mm^2
smiData.Solid(41).PoI = [7.9580317880926212e-10 0 0];  % kg*mm^2
smiData.Solid(41).color = [0.77647058823529413 0.75686274509803919 0.73725490196078436];
smiData.Solid(41).opacity = 1;
smiData.Solid(41).ID = 'torque nut 08_iso*:*ISO 10511-M6-N';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(42).mass = 0.0085072313203925533;  % kg
smiData.Solid(42).CoM = [0 0 6.2887805764107565];  % mm
smiData.Solid(42).MoI = [0.30075396645327629 0.30075396645327618 0.19598995160168808];  % kg*mm^2
smiData.Solid(42).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(42).color = [0.99607843137254903 0.87058823529411766 0.76078431372549016];
smiData.Solid(42).opacity = 1;
smiData.Solid(42).ID = 'Max_BagueVisBilles*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(43).mass = 0.0033163069279797692;  % kg
smiData.Solid(43).CoM = [0 0 0];  % mm
smiData.Solid(43).MoI = [0.61806076509981578 0.36295180544851546 0.36295180544851546];  % kg*mm^2
smiData.Solid(43).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(43).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(43).opacity = 1;
smiData.Solid(43).ID = '3200_a-2rs1-2_1_01*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(44).mass = 0.00032979195973040448;  % kg
smiData.Solid(44).CoM = [-2.7513064809067247 -2.351227473989441e-12 0];  % mm
smiData.Solid(44).MoI = [0.03394086895044434 0.017451270963950129 0.017451270963950129];  % kg*mm^2
smiData.Solid(44).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(44).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(44).opacity = 1;
smiData.Solid(44).ID = '3200_a-2rs1-2_1_03*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(45).mass = 0.0001041589580910989;  % kg
smiData.Solid(45).CoM = [-6.4259799677160894 0 0];  % mm
smiData.Solid(45).MoI = [0.012658331547016744 0.0063309233026513879 0.0063309233026513914];  % kg*mm^2
smiData.Solid(45).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(45).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(45).opacity = 1;
smiData.Solid(45).ID = '3200_a-2rs1-2_1_05*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(46).mass = 0.00010415895809109894;  % kg
smiData.Solid(46).CoM = [6.4259799677160903 0 0];  % mm
smiData.Solid(46).MoI = [0.012658331547016741 0.0063309233026513862 0.0063309233026513896];  % kg*mm^2
smiData.Solid(46).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(46).color = [0.25098039215686274 0.25098039215686274 0.25098039215686274];
smiData.Solid(46).opacity = 1;
smiData.Solid(46).ID = '3200_a-2rs1-2_1_06*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(47).mass = 0.0016044837982867365;  % kg
smiData.Solid(47).CoM = [0 0 0];  % mm
smiData.Solid(47).MoI = [0.070683313391295799 0.064693745182619486 0.064693745182619458];  % kg*mm^2
smiData.Solid(47).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(47).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(47).opacity = 1;
smiData.Solid(47).ID = '3200_a-2rs1-2_1_02*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(48).mass = 0.00032979195973040448;  % kg
smiData.Solid(48).CoM = [2.7513064809067256 -2.3509137504655475e-12 0];  % mm
smiData.Solid(48).MoI = [0.03394086895044434 0.017451270963950129 0.017451270963950129];  % kg*mm^2
smiData.Solid(48).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(48).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(48).opacity = 1;
smiData.Solid(48).ID = '3200_a-2rs1-2_1_04*:*Default';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(49).mass = 0.0005813909904549612;  % kg
smiData.Solid(49).CoM = [0 0 1.5];  % mm
smiData.Solid(49).MoI = [0.012472653592104093 0.012472653592104093 0.02407322069852574];  % kg*mm^2
smiData.Solid(49).PoI = [0 0 0];  % kg*mm^2
smiData.Solid(49).color = [0.75294117647058822 0.75294117647058822 0.75294117647058822];
smiData.Solid(49).opacity = 1;
smiData.Solid(49).ID = 'Max_RondelleD6.5*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(50).mass = 0.096252440387925228;  % kg
smiData.Solid(50).CoM = [-4.5502193470670393e-06 -2.6975110132764162e-07 17.04576114386624];  % mm
smiData.Solid(50).MoI = [28.414039413393596 24.149260697059329 30.317577774904567];  % kg*mm^2
smiData.Solid(50).PoI = [-4.659241995592433e-07 3.0945458641036863e-06 3.8668410029165374e-06];  % kg*mm^2
smiData.Solid(50).color = [0.8666666666666667 0.90980392156862744 1];
smiData.Solid(50).opacity = 1;
smiData.Solid(50).ID = 'Max_SupportEcrou*:*Défaut';

%Inertia Type - Custom
%Visual Properties - Simple
smiData.Solid(51).mass = 0.01066102909910091;  % kg
smiData.Solid(51).CoM = [0.0001423688323700297 0.0015362183120968807 14.268756265177718];  % mm
smiData.Solid(51).MoI = [1.2169556742658092 1.2170415938959913 1.0203474176290905];  % kg*mm^2
smiData.Solid(51).PoI = [-0.00026737878176953813 4.4501714328850036e-06 2.9095234324482974e-06];  % kg*mm^2
smiData.Solid(51).color = [0.50196078431372548 0.50196078431372548 0.50196078431372548];
smiData.Solid(51).opacity = 1;
smiData.Solid(51).ID = 'Max_EcrouBilles*:*Défaut';


%============= Joint =============%
%X Revolute Primitive (Rx) %Y Revolute Primitive (Ry) %Z Revolute Primitive (Rz)
%X Prismatic Primitive (Px) %Y Prismatic Primitive (Py) %Z Prismatic Primitive (Pz) %Spherical Primitive (S)
%Constant Velocity Primitive (CV) %Lead Screw Primitive (LS)
%Position Target (Pos)

%Initialize the CylindricalJoint structure array by filling in null values.
smiData.CylindricalJoint(2).Rz.Pos = 0.0;
smiData.CylindricalJoint(2).Pz.Pos = 0.0;
smiData.CylindricalJoint(2).ID = '';

smiData.CylindricalJoint(1).Rz.Pos = 28.080150144091331;  % deg
smiData.CylindricalJoint(1).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(1).ID = '[MaxV2_BRAS-1:-:MaxV2_ECROU-1]';

%This joint has been chosen as a cut joint. Simscape Multibody treats cut joints as algebraic constraints to solve closed kinematic loops. The imported model does not use the state target data for this joint.
smiData.CylindricalJoint(2).Rz.Pos = -49.191433890262971;  % deg
smiData.CylindricalJoint(2).Pz.Pos = 0;  % mm
smiData.CylindricalJoint(2).ID = '[MaxV2_VIS-1:-:MaxV2_ECROU-1]';


%Initialize the RevoluteJoint structure array by filling in null values.
smiData.RevoluteJoint(3).Rz.Pos = 0.0;
smiData.RevoluteJoint(3).ID = '';

smiData.RevoluteJoint(1).Rz.Pos = 0.051192219973163526;  % deg
smiData.RevoluteJoint(1).ID = '[MaxV2_BATI-1:-:MaxV2_BRAS-1]';

smiData.RevoluteJoint(2).Rz.Pos = -151.86865763593545;  % deg
smiData.RevoluteJoint(2).ID = '[MaxV2_BATI-1:-:MaxV2_STATOR-1]';

smiData.RevoluteJoint(3).Rz.Pos = -49.191433890262999;  % deg
smiData.RevoluteJoint(3).ID = '[MaxV2_STATOR-1:-:MaxV2_VIS-1]';

